<?php
// Konfigurasi koneksi
$host = "localhost";
$user = "root";
$pass = ""; // Ganti jika password MySQL Anda berbeda
$db   = "uas_project";

// 1. Koneksi ke MySQL (tanpa database dulu)
$conn = mysqli_connect($host, $user, $pass);
if (!$conn) {
    die("Koneksi ke MySQL gagal: " . mysqli_connect_error());
}

// 2. Buat database jika belum ada
$sql = "CREATE DATABASE IF NOT EXISTS $db";
if (mysqli_query($conn, $sql)) {
    echo "Database '$db' berhasil dibuat/ada.<br>";
} else {
    die("Gagal membuat database: " . mysqli_error($conn));
}

// 3. Pilih database
mysqli_select_db($conn, $db);

// 4. Buat tabel users
$sql = "CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nama VARCHAR(100) NOT NULL,
    role ENUM('admin', 'petugas', 'pelapor') NOT NULL,
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if (mysqli_query($conn, $sql)) {
    echo "Tabel 'users' berhasil dibuat/ada.<br>";
} else {
    die("Gagal membuat tabel users: " . mysqli_error($conn));
}

// 5. Buat tabel laporan
$sql = "CREATE TABLE IF NOT EXISTS laporan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    judul VARCHAR(255) NOT NULL,
    isi TEXT NOT NULL,
    status ENUM('baru', 'proses', 'selesai', 'ditolak') DEFAULT 'baru',
    tanggal_lapor DATE NOT NULL,
    gambar VARCHAR(255),
    FOREIGN KEY (user_id) REFERENCES users(id)
)";
if (mysqli_query($conn, $sql)) {
    echo "Tabel 'laporan' berhasil dibuat/ada.<br>";
} else {
    die("Gagal membuat tabel laporan: " . mysqli_error($conn));
}

// 6. Buat tabel tanggapan
$sql = "CREATE TABLE IF NOT EXISTS tanggapan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    laporan_id INT NOT NULL,
    petugas_id INT NOT NULL,
    isi_tanggapan TEXT NOT NULL,
    tanggal_tanggapan DATE NOT NULL,
    FOREIGN KEY (laporan_id) REFERENCES laporan(id),
    FOREIGN KEY (petugas_id) REFERENCES users(id)
)";
if (mysqli_query($conn, $sql)) {
    echo "Tabel 'tanggapan' berhasil dibuat/ada.<br>";
} else {
    die("Gagal membuat tabel tanggapan: " . mysqli_error($conn));
}

// 7. Insert admin default jika belum ada
$admin_email = 'admin@gmail.com';
$admin_username = 'admin';
$admin_nama = 'Administrator';
$admin_role = 'admin';
$admin_password_plain = 'admin123';
$admin_password_hash = password_hash($admin_password_plain, PASSWORD_DEFAULT);

// Cek apakah tabel users kosong
$sql = "SELECT COUNT(*) as jumlah FROM users";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
if ($row['jumlah'] == 0) {
    // Insert admin
    $sql = "INSERT INTO users (username, password, nama, role, email) VALUES ('$admin_username', '$admin_password_hash', '$admin_nama', '$admin_role', '$admin_email')";
    if (mysqli_query($conn, $sql)) {
        echo "Akun admin berhasil dibuat (email: $admin_email, password: $admin_password_plain)<br>";
        echo "Hash password admin yang digunakan:<br><code>$admin_password_hash</code><br>";
        echo "Jika ingin insert manual di phpMyAdmin, gunakan SQL berikut:<br>";
        echo "<pre>INSERT INTO users (username, password, nama, role, email) VALUES ('admin', '$admin_password_hash', 'Administrator', 'admin', 'admin@gmail.com');</pre>";
    } else {
        echo "Gagal membuat akun admin: " . mysqli_error($conn) . "<br>";
    }
} else {
    echo "Akun admin sudah ada atau tabel users sudah terisi.<br>";
}

echo "<br>Setup database selesai. Demi keamanan, hapus file ini setelah selesai.";
mysqli_close($conn);
?> 