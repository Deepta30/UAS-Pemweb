<?php
session_start();
header('Content-Type: application/json');
if(isset($_SESSION['nama'])) {
    echo json_encode(["nama"=>$_SESSION['nama']]);
} else {
    echo json_encode(["nama"=>null]);
} 