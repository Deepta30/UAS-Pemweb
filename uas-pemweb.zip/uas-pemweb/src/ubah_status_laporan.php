<?php
session_start();
header('Content-Type: application/json');
$koneksi = mysqli_connect("localhost", "root", "", "uas_project");
if (!$koneksi) { echo json_encode(["success"=>false]); exit(); }
if (!isset($_SESSION['id'])) { echo json_encode(["success"=>false]); exit(); }
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'], $_POST['status'])) {
    $id = intval($_POST['id']);
    $status = mysqli_real_escape_string($koneksi, $_POST['status']);
    $q = mysqli_query($koneksi, "UPDATE laporan SET status='$status' WHERE id='$id'");
    echo json_encode(["success"=>!!$q]); exit();
}
echo json_encode(["success"=>false]); 