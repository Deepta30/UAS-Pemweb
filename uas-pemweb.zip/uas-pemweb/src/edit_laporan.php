<?php
session_start();
header('Content-Type: application/json');
$koneksi = mysqli_connect("localhost", "root", "", "uas_project");
if (!$koneksi) {
    echo json_encode(["success"=>false]); exit();
}
if (!isset($_SESSION['id'])) {
    echo json_encode(["success"=>false]); exit();
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'], $_POST['isi'])) {
    $id = intval($_POST['id']);
    $user_id = $_SESSION['id'];
    $isi = mysqli_real_escape_string($koneksi, $_POST['isi']);
    $q = mysqli_query($koneksi, "UPDATE laporan SET isi='$isi' WHERE id='$id' AND user_id='$user_id'");
    echo json_encode(["success"=>!!$q]);
    exit();
}
echo json_encode(["success"=>false]); 