<?php
$koneksi = mysqli_connect("localhost", "root", "", "uas_project");
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Pagination
$per_page = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$start = ($page - 1) * $per_page;

// Ambil data laporan + nama user
$q_laporan = mysqli_query($koneksi, "
    SELECT laporan.*, users.nama 
    FROM laporan 
    JOIN users ON laporan.user_id = users.id 
    ORDER BY laporan.tanggal_lapor DESC, laporan.id DESC 
    LIMIT $start, $per_page
");

// Hitung total laporan
$total_query = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM laporan");
$total_data = mysqli_fetch_assoc($total_query)['total'];
$total_page = ceil($total_data / $per_page);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Daftar Laporan | Admin</title>
  <link rel="stylesheet" href="../src/style.css">
</head>
<body class="bg-gray-100">
  <div class="flex min-h-screen">
    <!-- Sidebar -->
    <aside class="flex flex-col w-64 bg-white shadow-lg h-screen">
      <div class="p-6 text-xl font-bold text-blue-600 border-b">Admin Panel</div>
      <nav class="p-4">
        <ul class="space-y-2 text-gray-700">
          <li><a href="./admin.php" class="block px-4 py-2 rounded hover:bg-blue-100">Dashboard</a></li>
          <li><a href="./pendaftaran-admin.html" class="block px-4 py-2 rounded hover:bg-blue-100">Pendaftaran</a></li>
          <li><a href="./data-pengguna-admin.html" class="block px-4 py-2 rounded hover:bg-blue-100">Data Pengguna</a></li>
          <li><a href="./laporan-admin.php" class="block px-4 py-2 rounded bg-blue-100 font-bold">Laporan</a></li>
        </ul>
      </nav>
    </aside>
    <!-- Main Content -->
    <main class="flex-1 p-6">
      <header class="flex justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-700">Daftar Laporan</h1>
      </header>
      <section class="bg-white p-4 rounded-lg shadow">
        <table class="w-full table-auto">
          <thead>
            <tr class="bg-gray-100 text-gray-600 text-left text-sm">
              <th class="p-2">Tanggal</th>
              <th class="p-2">Nama User</th>
              <th class="p-2">Judul</th>
              <th class="p-2">Isi</th>
              <th class="p-2">Status</th>
            </tr>
          </thead>
          <tbody class="text-sm text-gray-700">
          <?php while($row = mysqli_fetch_assoc($q_laporan)): ?>
            <tr class="border-b">
              <td class="p-2"><?php echo htmlspecialchars($row['tanggal_lapor']); ?></td>
              <td class="p-2"><?php echo htmlspecialchars($row['nama']); ?></td>
              <td class="p-2"><?php echo htmlspecialchars($row['judul']); ?></td>
              <td class="p-2"><?php echo htmlspecialchars($row['isi']); ?></td>
              <td class="p-2 <?php
                if($row['status']==='proses') echo 'text-yellow-600 font-medium';
                elseif($row['status']==='selesai') echo 'text-green-600 font-medium';
                elseif($row['status']==='ditolak') echo 'text-red-600 font-semibold';
              ?>"><?php echo htmlspecialchars(ucfirst($row['status'])); ?></td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
        <!-- Pagination -->
        <div class="mt-4 flex justify-center">
          <?php for($i=1; $i<=$total_page; $i++): ?>
            <a href="?page=<?php echo $i; ?>" class="px-3 py-1 mx-1 rounded <?php echo $i==$page?'bg-blue-500 text-white':'bg-gray-200 text-gray-700'; ?>"><?php echo $i; ?></a>
          <?php endfor; ?>
        </div>
      </section>
    </main>
  </div>
</body>
</html>