<?php
session_start();

// Debug: log POST data
file_put_contents('debug_login.txt', "POST: " . print_r($_POST, true));

if (empty($_POST)) {
    die('ERROR: Form login tidak mengirim data POST ke server. Cek kembali action form dan pastikan tidak ada JavaScript yang mencegah submit.');
}

// Koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "uas_project");
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Jika form login dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Ambil data berdasarkan email
    $query = "SELECT * FROM users WHERE email = '$email' LIMIT 1";
    $result = mysqli_query($koneksi, $query);
    file_put_contents('debug_login.txt', "\nQuery: $query\nResult: " . mysqli_num_rows($result), FILE_APPEND);

    if (mysqli_num_rows($result) == 1) {
        $data = mysqli_fetch_assoc($result);
        file_put_contents('debug_login.txt', "\nData: " . print_r($data, true), FILE_APPEND);

        // Cek password hash
        $verify = password_verify($password, $data['password']);
        file_put_contents('debug_login.txt', "\nPassword verify: " . ($verify ? 'true' : 'false'), FILE_APPEND);
        if ($verify) {
            // Simpan session setelah login sukses
            $_SESSION['id'] = $data['id'];
            $_SESSION['nama'] = $data['nama'];
            $_SESSION['email'] = $data['email'];
            $_SESSION['role'] = $data['role'];

            // Redirect sesuai peran
            switch ($data['role']) {
                case 'admin':
                    header("Location: admin.php");
                    break;
                case 'petugas':
                    header("Location: laporan-petugas.html");
                    break;
                case 'pelapor':
                    header("Location: pelapor.html");
                    break;
                default:
                    echo "<script>alert('Peran tidak valid'); window.history.back();</script>";
            }
            exit();
        } else {
            echo "<script>alert('Password salah!'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Email tidak ditemukan!'); window.history.back();</script>";
    }
}
?>
