<?php
session_start();
header('Content-Type: application/json');
$koneksi = mysqli_connect("localhost", "root", "", "uas_project");
if (!$koneksi) {
    echo json_encode(["success"=>false, "msg"=>"Koneksi gagal"]); exit();
}
if (!isset($_SESSION['id'])) {
    echo json_encode(["success"=>false, "msg"=>"Belum login"]); exit();
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['isi'])) {
    $user_id = $_SESSION['id'];
    $isi = mysqli_real_escape_string($koneksi, $_POST['isi']);
    $tanggal = date('Y-m-d');
    $query = "INSERT INTO laporan (user_id, judul, isi, tanggal_lapor, status) VALUES ('$user_id', 'Pengaduan', '$isi', '$tanggal', 'proses')";
    if (mysqli_query($koneksi, $query)) {
        echo json_encode(["success"=>true]);
    } else {
        echo json_encode(["success"=>false, "msg"=>mysqli_error($koneksi)]);
    }
    exit();
}
echo json_encode(["success"=>false, "msg"=>"Request tidak valid"]); 