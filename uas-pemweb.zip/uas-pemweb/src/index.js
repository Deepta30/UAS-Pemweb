const daftarin = document.getElementById('daftar');
const masukin = document.getElementById('masuk');
const password = document.getElementById('password');
const konfirmasi = document.getElementById('konfirmasi');
const kembali_1 = document.getElementById('quit_1');
const kembali_2 = document.getElementById('quit_2');
const kembali_3 = document.getElementById('quit_3');
const detik = document.getElementById('kirim');
const passwordField = document.querySelectorAll('.pw');
const iconMenu = document.getElementById('menu');
const menuElement = document.querySelector('.menu');
const judulElement = document.querySelector('.judul');
const btn = document.getElementById('toggleDark');
const html = document.documentElement;


kembali_1.addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('pageMasuk').style.display = 'none';
});

kembali_2.addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('pageDaftar').style.display = 'none';
});

kembali_3.addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('pageLupa').style.display = 'none';
});


daftarin.addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('pageDaftar').style.cssText += 'display: flex; position: absolute; z-index: 1;';
    document.getElementById('pageMasuk').style.display = 'none';
    document.getElementById('pageLupa').style.display = 'none';
});

masukin.addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('pageMasuk').style.cssText += 'display: flex; position: absolute; z-index: 1;';
    document.getElementById('pageDaftar').style.display = 'none';
    document.getElementById('pageLupa').style.display = 'none';
});

adaAkun.addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('pageMasuk').style.cssText += 'display: flex; position: absolute; z-index: 1;';
    document.getElementById('pageDaftar').style.display = 'none';
    document.getElementById('pageLupa').style.display = 'none';
});

buatAkun.addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('pageDaftar').style.cssText += 'display: flex; position: absolute; z-index: 1;';
    document.getElementById('pageMasuk').style.display = 'none';
    document.getElementById('pageLupa').style.display = 'none';
});

lupa.addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('pageLupa').style.display = 'flex';
    document.getElementById('pageLupa').style.cssText += 'position: absolute; z-index: 1;';
    document.getElementById('pageMasuk').style.display = 'none';
    document.getElementById('pageDaftar').style.display = 'none';
});

const icons = document.querySelectorAll('.lihat');

icons.forEach(icon => {
    icon.addEventListener('click', function (event) {
        event.preventDefault();
        
        const passwordField = this.parentElement.querySelector('.pw');

        if (passwordField.getAttribute('type') === 'text') {
            passwordField.setAttribute('type', 'password');
            this.setAttribute('src', '../asset/visibility_off.png');
        } else {
            passwordField.setAttribute('type', 'text');
            this.setAttribute('src', '../asset/visibility_on.png');
        }
    });
});


document.querySelector('.lihat_2').addEventListener('click', function (event) {
    event.preventDefault();

    const passwordField_2 = this.parentElement.querySelector('.pw_2');

    if (passwordField_2.getAttribute('type') === 'text') {
        passwordField_2.setAttribute('type', 'password');
        this.setAttribute('src', '../asset/visibility_off.png');
    } else {
        passwordField_2.setAttribute('type', 'text');
        this.setAttribute('src', '../asset/visibility_on.png');
    }
});

detik.addEventListener('click', function(event) {
    event.preventDefault();
    alert('Email terkirim'); // Tindakan yang diinginkan saat tombol diklik
    countdown(); // Panggil fungsi countdown saat tombol diklik
});

function countdown() {
    const timerElement = document.getElementById('timer'); // Elemen untuk menampilkan hitungan mundur
    let timeLeft = 60; // Waktu awal (60 detik)

    // Perbarui teks elemen setiap detik
    const interval = setInterval(() => {
        if (timeLeft <= 0) {
            clearInterval(interval); // Hentikan interval ketika waktu habis
            kirim.style.display = 'block'; // Tampilkan tombol kirim
            timerElement.style.display = 'none' // Sembunyikan timer
        } else {
            timerElement.textContent = `${timeLeft} detik`; // Tampilkan waktu tersisa
            kirim.style.display = 'none'; // Sembunyikan tombol kirim
            timerElement.style.display = 'block' // Sembunyikan timer
            timeLeft--; // Kurangi waktu
        }
    }, 1000); // Jalankan setiap 1 detik
};

iconMenu.addEventListener('click', function (event) {
    event.preventDefault();

    const isHidden = menuElement.classList.contains('invisible');

    if (isHidden) {
        // Tampilkan menu
        menuElement.classList.remove('invisible', 'opacity-0', '-translate-y-5');
        menuElement.classList.add('opacity-100', 'translate-y-0');

        judulElement.style.display = 'none';
        iconMenu.setAttribute('src', '../asset/close.png');
        
    } else {
        // Sembunyikan menu
        menuElement.classList.remove('opacity-100', 'translate-y-0');
        menuElement.classList.add('opacity-0', '-translate-y-5', 'invisible');

        judulElement.style.display = 'block';
        iconMenu.setAttribute('src', '../asset/bar.png');
    }
});


window.addEventListener('resize', function() {
    if (window.innerWidth >= 1024) {
        menuElement.classList.remove('opacity-100', 'translate-y-0');
        menuElement.classList.add('opacity-0', '-translate-y-5', 'invisible');
        judulElement.style.display = 'block';
        iconMenu.setAttribute('src', '../asset/bar.png');
    }
});

function logout() {
    const konfirmasi = confirm("Apakah Anda yakin ingin logout?");
    if (konfirmasi) {
        alert("Berhasil logout");
        window.location.href = "home.html";
    }
};


