<?php
// Koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "uas_project");
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Query statistik
// 1. Jumlah user terdaftar
$q_user = mysqli_query($koneksi, "SELECT COUNT(*) as total_user FROM users");
$total_user = mysqli_fetch_assoc($q_user)['total_user'];

// 2. Total pengaduan
$q_pengaduan = mysqli_query($koneksi, "SELECT COUNT(*) as total_pengaduan FROM laporan");
$total_pengaduan = mysqli_fetch_assoc($q_pengaduan)['total_pengaduan'];

// 3. Pengaduan diproses
$q_proses = mysqli_query($koneksi, "SELECT COUNT(*) as total_proses FROM laporan WHERE status='proses'");
$total_proses = mysqli_fetch_assoc($q_proses)['total_proses'];

// 4. Pengaduan ditolak
$q_ditolak = mysqli_query($koneksi, "SELECT COUNT(*) as total_ditolak FROM laporan WHERE status='ditolak'");
$total_ditolak = mysqli_fetch_assoc($q_ditolak)['total_ditolak'];

// 5. Pengaduan selesai
$q_selesai = mysqli_query($koneksi, "SELECT COUNT(*) as total_selesai FROM laporan WHERE status='selesai'");
$total_selesai = mysqli_fetch_assoc($q_selesai)['total_selesai'];

// Query pengaduan terbaru (10 terakhir)
$q_terbaru = mysqli_query($koneksi, "SELECT laporan.tanggal_lapor, users.nama, laporan.judul, laporan.status FROM laporan JOIN users ON laporan.user_id = users.id ORDER BY laporan.tanggal_lapor DESC, laporan.id DESC LIMIT 10");

// Pagination setup
$per_page = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$start = ($page - 1) * $per_page;
// Total data
$total_query = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM users");
$total_data = mysqli_fetch_assoc($total_query)['total'];
$total_page = ceil($total_data / $per_page);
// Ambil data sesuai halaman
$q_users = mysqli_query($koneksi, "SELECT * FROM users ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DiLaporin | Admin</title>
  <link rel="stylesheet" href="../src/style.css">
</head>
<body class="bg-gray-100">
  <!-- Wrapper -->
  <div class="flex min-h-screen">
    <!-- Sidebar -->
    <aside class="flex flex-col w-64 bg-white shadow-lg h-screen">
      <div class="p-6 text-xl font-bold text-blue-600 border-b">Admin Panel</div>
      <nav class="p-4">
        <ul class="space-y-2 text-gray-700">
          <li><a href="#" class="block px-4 py-2 rounded hover:bg-blue-100">Dashboard</a></li>
          <li><a href="./pendaftaran-admin.html" class="block px-4 py-2 rounded hover:bg-blue-100">Pendaftaran</a></li>
          <li><a href="./data-pengguna-admin.html" class="block px-4 py-2 rounded hover:bg-blue-100">Data Pengguna</a></li>
          <li><a href="./laporan-admin.html" class="block px-4 py-2 rounded hover:bg-blue-100">Laporan</a></li>
        </ul>
      </nav>
    </aside>
    <!-- Main Content -->
    <main class="flex-1 p-6">
      <!-- Header -->
      <header class="flex justify-between mb-6">
        <h1 class="text-2xl font-bold text-gray-700">Dashboard</h1>
        <button onclick="logout()" class="bg-red-500 h-[35px] w-[10%] rounded self-center text-white hover:cursor-pointer active:bg-red-700">Logout</button>
      </header>
      <!-- Stats Cards -->
      <section class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div class="bg-white p-4 rounded-lg shadow">
          <h2 class="text-sm font-medium text-gray-500">Pengguna Terdaftar</h2>
          <p class="text-2xl font-bold text-gray-800"><?php echo $total_user; ?></p>
        </div>
        <div class="bg-white p-4 rounded-lg shadow">
          <h2 class="text-sm font-medium text-gray-500">Total Pengaduan</h2>
          <p class="text-2xl font-bold text-gray-800"><?php echo $total_pengaduan; ?></p>
        </div>
        <div class="bg-white p-4 rounded-lg shadow">
          <h2 class="text-sm font-medium text-gray-500">Diproses</h2>
          <p class="text-2xl font-bold text-yellow-600"><?php echo $total_proses; ?></p>
        </div>
        <div class="bg-white p-4 rounded-lg shadow">
          <h2 class="text-sm font-medium text-gray-500">Ditolak</h2>
          <p class="text-2xl font-bold text-red-600"><?php echo $total_ditolak; ?></p>
        </div>
        <div class="bg-white p-4 rounded-lg shadow">
          <h2 class="text-sm font-medium text-gray-500">Pengaduan Selesai</h2>
          <p class="text-2xl font-bold text-green-600"><?php echo $total_selesai; ?></p>
        </div>
      </section>
      <!-- Recent Complaints Table (dinamis) -->
      <section class="bg-white p-4 rounded-lg shadow">
        <h2 class="text-lg font-semibold text-gray-700 mb-4">Pengaduan Terbaru</h2>
        <table class="w-full table-auto">
          <thead>
            <tr class="bg-gray-100 text-gray-600 text-left text-sm">
              <th class="p-2">Tanggal</th>
              <th class="p-2">Nama</th>
              <th class="p-2">Judul</th>
              <th class="p-2">Status</th>
            </tr>
          </thead>
          <tbody class="text-sm text-gray-700">
          <?php while($row = mysqli_fetch_assoc($q_terbaru)): ?>
            <tr class="border-b">
              <td class="p-2"><?php echo htmlspecialchars($row['tanggal_lapor']); ?></td>
              <td class="p-2"><?php echo htmlspecialchars($row['nama']); ?></td>
              <td class="p-2"><?php echo htmlspecialchars($row['judul']); ?></td>
              <td class="p-2 <?php
                if($row['status']==='proses') echo 'text-yellow-600 font-medium';
                elseif($row['status']==='selesai') echo 'text-green-600 font-medium';
                elseif($row['status']==='ditolak') echo 'text-red-600 font-semibold';
              ?>"><?php echo htmlspecialchars(ucfirst($row['status'])); ?></td>
            </tr>
          <?php endwhile; ?>
          </tbody>
        </table>
      </section>
    </main>
  </div>
  <script src="./index.js"></script>
</body>
</html>
