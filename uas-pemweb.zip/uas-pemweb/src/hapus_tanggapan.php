<?php
session_start();
header('Content-Type: application/json');
$koneksi = mysqli_connect("localhost", "root", "", "uas_project");
if (!$koneksi) { echo json_encode(["success"=>false]); exit(); }
if (!isset($_SESSION['id'])) { echo json_encode(["success"=>false]); exit(); }
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $id = intval($_POST['id']);
    $petugas_id = $_SESSION['id'];
    $q = mysqli_query($koneksi, "DELETE FROM tanggapan WHERE id='$id' AND petugas_id='$petugas_id'");
    echo json_encode(["success"=>!!$q]); exit();
}
echo json_encode(["success"=>false]); 