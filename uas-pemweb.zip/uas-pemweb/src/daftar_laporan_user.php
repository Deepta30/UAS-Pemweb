<?php
session_start();
header('Content-Type: application/json');
$koneksi = mysqli_connect("localhost", "root", "", "uas_project");
if (!$koneksi) {
    echo json_encode(["data"=>[],"total_data"=>0,"total_page"=>1,"page"=>1,"per_page"=>10]); exit();
}
if (!isset($_SESSION['id'])) {
    echo json_encode(["data"=>[],"total_data"=>0,"total_page"=>1,"page"=>1,"per_page"=>10]); exit();
}
$user_id = $_SESSION['id'];
$per_page = isset($_GET['per_page']) ? max(1, intval($_GET['per_page'])) : 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$start = ($page-1)*$per_page;
$total_query = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM laporan WHERE user_id='$user_id'");
$total_data = mysqli_fetch_assoc($total_query)['total'];
$total_page = max(1, ceil($total_data/$per_page));
$q = mysqli_query($koneksi, "SELECT id, isi, status, tanggal_lapor FROM laporan WHERE user_id='$user_id' ORDER BY id DESC LIMIT $start, $per_page");
$data = [];
while($row = mysqli_fetch_assoc($q)) {
    $data[] = $row;
}
echo json_encode([
    "data"=>$data,
    "total_data"=>$total_data,
    "total_page"=>$total_page,
    "page"=>$page,
    "per_page"=>$per_page
]);