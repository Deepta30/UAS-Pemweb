<?php
session_start();
header('Content-Type: application/json');
$koneksi = mysqli_connect("localhost", "root", "", "uas_project");
if (!$koneksi) { echo json_encode([]); exit(); }
// Ambil semua laporan dan tanggapan (LEFT JOIN)
$q = mysqli_query($koneksi, "SELECT l.id as laporan_id, l.tanggal_lapor, u.nama as nama_pelapor, l.isi as isi_laporan, t.id as tanggapan_id, t.isi_tanggapan as tanggapan, t.tanggal_tanggapan FROM laporan l JOIN users u ON l.user_id=u.id LEFT JOIN tanggapan t ON t.laporan_id=l.id");
$data = [];
while($row = mysqli_fetch_assoc($q)) { $data[] = $row; }
echo json_encode($data); 