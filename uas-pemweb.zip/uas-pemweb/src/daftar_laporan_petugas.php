<?php
header('Content-Type: application/json');
$koneksi = mysqli_connect("localhost", "root", "", "uas_project");
if (!$koneksi) { echo json_encode([]); exit(); }
$q = mysqli_query($koneksi, "SELECT l.tanggal_lapor, u.nama, l.isi, l.status FROM laporan l JOIN users u ON l.user_id=u.id ORDER BY l.tanggal_lapor DESC, l.id DESC");
$data = [];
while($row = mysqli_fetch_assoc($q)) { $data[] = $row; }
echo json_encode($data); 