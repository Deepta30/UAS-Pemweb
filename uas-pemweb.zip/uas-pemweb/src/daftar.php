<?php
// Koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "uas_project");

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Cek apakah form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = htmlspecialchars($_POST['nama']);
    $email = htmlspecialchars($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // enkripsi password
    $konfirmasi = $_POST['konfirmasi'];
    $role = $_POST['peran'];

    // Validasi konfirmasi password
    if ($_POST['password'] !== $konfirmasi) {
        echo "<script>alert('Konfirmasi password tidak cocok'); window.history.back();</script>";
        exit();
    }

    // Cek apakah email sudah terdaftar di tabel users
    $cek_email = mysqli_query($koneksi, "SELECT * FROM users WHERE email='$email'");
    if (mysqli_num_rows($cek_email) > 0) {
        echo "<script>alert('Email sudah digunakan'); window.history.back();</script>";
        exit();
    }

    // Simpan ke database tabel users
    $query = "INSERT INTO users (nama, email, password, role, username) VALUES ('$nama', '$email', '$password', '$role', '$email')";
    if (mysqli_query($koneksi, $query)) {
        header("Location: home.html"); // redirect ke halaman home setelah berhasil daftar
        exit();
    } else {
        echo "Gagal mendaftar: " . mysqli_error($koneksi);
    }
}
?>
